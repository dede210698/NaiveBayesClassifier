import os
import math
f2=open("category.csv","w+")
path=os.getcwd()+'/Dokumen'


def token(l):
    s = '\n'.join(l)
    s = s.replace("&lt","")
    s = s.replace(",","")
    s = s.replace("!","")
    s = s.replace("@","")
    s = s.replace("#","")
    s = s.replace("%","")
    s = s.replace("$","")
    s = s.replace("^","")
    s = s.replace("&","")
    s = s.replace("*","")
    s = s.replace("(","")
    s = s.replace(")","")
    s = s.replace("-","")
    s = s.replace("+","")
    s = s.replace("<","")
    s = s.replace(".","")
    s = s.replace(">","")
    s = s.replace("/","")
    s = s.replace("?","")
    s = s.replace("_","")
    s = s.replace("=","")
    s = s.replace("{","")
    s = s.replace("[","")
    s = s.replace("}","")
    s = s.replace("]","")
    s = s.replace("\\","")
    s = s.replace("|","")
    s = s.replace(":","")
    s = s.replace(";","")
    s = s.replace("'","")
    s = s.replace("\"","")
    return s

l=[]
i=0
for foldername in os.listdir(path):
    path = os.getcwd()+'\Dokumen\\'+foldername
    j=0
    f2.write(foldername+"\n")
    for file in os.listdir(path):    
        j=j+1
    j = j*70/100
    i=i+1
    l.append(math.floor(j))
f2.close()


i=0
j=0
path=os.getcwd()+'/Dokumen'
for foldername in os.listdir(path):
    
    try:
        f = open("tokenize_"+foldername+".csv","w+")
        list_word=[]
        path = os.getcwd()+'\Dokumen\\'+foldername
        j=0
        for filename in os.listdir(path):
            if j < l[i]:
                f3=open(path+"\\"+filename,"r")
                f3_str = f3.readlines()
                for x in f3_str:
                    for y in x.split():
                        list_word.append(y)
                f3.close()
            word = token(list_word)
            j=j+1
        f.write(word.lower())
        f.close()
        i=i+1
    except Exception as e:
        raise e
