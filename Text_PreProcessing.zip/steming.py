import os
from nltk.stem.porter import PorterStemmer


stemmer = PorterStemmer()

f = open("category.csv","r")
f_str = f.readlines()
list_categories=[]
for every_word in f_str:
    word = ''.join(every_word)
    word = word.replace("\n","")
    list_categories.append(word)
f.close()

path=os.getcwd()+'/stop'
i=0
for filename in os.listdir(path):
    try:
        f = open(path+"\\"+filename,"r")
        f2 = open("stemming_"+list_categories[i]+".csv","w+")
        f_str = f.readlines()
        for word in f_str:
            words = ''.join(word)
            words = words.replace("\n","")
            f2.write(stemmer.stem(words)+'\n')
        f.close()
        f2.close()
        i=i+1
    except Exception as e:
        raise e
