1.extract dokumen.zip
2.jalankan tokenize.py
3.buat folder dengan nama token
4.pindahkan file darin hasil langkah nomor 2 kedalam folder token
5.jalankan stopwords.py
6.buat folder dengan nama stop
7.pindahkan file darin hasil langkah nomor 6 kedalam folder stop
8.jalankan steming.py (hatus ada nltk porterstemmer)
9.buat folder dengan nama stem
10.pindahkan file darin hasil langkah nomor 9 kedalam folder stem