import os

def same_words(x):
    f3 = open("list-stop2.csv","r")
    f3_str = f3.readlines()
    cek = False
    for word in f3_str:
        if x == word:
            cek = True
    return cek

f = open("category.csv","r")
f_str = f.readlines()
list_categories=[]
for every_word in f_str:
    word = ''.join(every_word)
    word = word.replace("\n","")
    list_categories.append(word)
f.close()

path=os.getcwd()+'/tokenize'
i=0
for filename in os.listdir(path):
    try:
        f = open(path+"\\"+filename,"r")
        f2 = open("stopwords_"+list_categories[i]+".csv","w+")
        f_str = f.readlines()
        for word in f_str:
            cek = same_words(word)
            if not cek:
                f2.write(word)
        f.close()
        f2.close()
        i=i+1
    except Exception as e:
        raise e